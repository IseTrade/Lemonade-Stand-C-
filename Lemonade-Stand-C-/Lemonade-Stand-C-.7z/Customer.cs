﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lemonade_Stand_C_
{
    public class Customer
    {
        List<Customer> customers;

    
    public void BuyOrNot()
        {

        }

   

    }
}
