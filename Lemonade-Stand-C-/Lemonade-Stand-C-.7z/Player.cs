﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lemonade_Stand_C_
{
    public class Player
    {



        public Player player;
        public Wallet wallet;
        public Inventory inventory;
        public List<Recipe> recipes;
    }
}
