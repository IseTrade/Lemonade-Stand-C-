﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lemonade_Stand_C_
{
    class Program
    {
        
        static void Main(string[] args)
        {
            //Weather weather = new Weather();

            //weather.DayForecast(); //tested ok for generating random daily weather.
            //Console.ReadLine();
            UI.ShowRules();



        }
        
    }
}
